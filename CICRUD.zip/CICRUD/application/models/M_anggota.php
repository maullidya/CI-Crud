<?php
class M_anggota extends CI_Model{
    public function tampil(){
        $query = $this->db->get('anggota');
        $data=$query->result_array();
        return $data;
    }
    public function save($anggota,$alamat){
        $data = array(
            'anggota' => $anggota,
            'alamat' => $alamat
    );
    
    $this->db->insert('anggota', $data); 
    }
    public function pilih_anggota($id){
        $query = $this->db->get_where('anggota', array('id' => $id));
        return $query;
    }
    public function edit($id,$anggota,$alamat){
        $data = array(
            'anggota' => $anggota,
            'alamat' => $alamat
    );
    
    $this->db->where('id', $id);
    $this->db->update('anggota', $data);
    }
    public function delete($id){
        $this->db->where('id', $id);
        $this->db->delete('anggota');
         
    }
}
?>