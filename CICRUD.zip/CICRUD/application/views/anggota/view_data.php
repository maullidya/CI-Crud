<a href="<?php echo base_url('anggota/tambah');?>">Tambah Anggota Baru</a>

<TABLE>
    <th>ANGGOTA</th>
    <th>ALAMAT</th>
    <th>UBAH</th>
    <th>HAPUS</th>
    <?php foreach ($anggota as $a): ?>
    <tr>
        <td><?php echo $a['anggota'] ?></td>
        <td><?php echo $a['alamat'] ?></td>
        <td><a href="<?php echo site_url('anggota/get_edit/'.$a['id']);?>">UBAH</a></td>
        <td><a href="<?php echo site_url('anggota/hapus/'.$a['id']);?>">HAPUS</a></td>
    </tr>
    <?php endforeach; ?>
</TABLE>