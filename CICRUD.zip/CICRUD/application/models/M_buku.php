<?php
class M_buku extends CI_Model{
    public function tampil(){
        $query = $this->db->get('buku');
        $data=$query->result_array();
        return $data;
    }
    public function save($buku,$penerbit){
        $data = array(
            'buku' => $buku,
            'penerbit' => $penerbit,
            'pengarang' => $pengarang
    );
    
    $this->db->insert('buku', $data); 
    }
    public function pilih_buku($id){
        $query = $this->db->get_where('buku', array('id' => $id));
        return $query;
    }
    public function edit($id,$buku,$penerbit,$pengarang){
        $data = array(
            'buku' => $buku,
            'penerbit' => $penerbit,
            'pengarang' => $pengarang
    );
    
    $this->db->where('id', $id);
    $this->db->update('buku', $data);
    }
    public function delete($id){
        $this->db->where('id', $id);
        $this->db->delete('buku');
         
    }
}
?>