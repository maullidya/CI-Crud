<form action="<?php echo base_url('buku/update');?>" method="post">
    <label>buku</label>
    <input type="text" name="buku" value="<?php echo $buku?>">
    <input type="hidden" name="id" value="<?= $id; ?>">
    <br>
    <label>penerbit</label>
    <input type="text" name="penerbit" value="<?php echo $penerbit?>">
    <br>
    <label>pengarang</label>
    <input type="text" name="pengarang" value="<?php echo $pengarang?>">
    <br>
    <input type="submit" name="Simpan" value="Simpan">
</form>