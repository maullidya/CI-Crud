<form action="<?php echo base_url('anggota/insert');?>" method="post">
    <label>Anggota</label>
    <input type="text" name="anggota">
    <br>
    <label>Alamat</label>
    <input type="text" name="alamat">
    <br>
    <input type="submit" name="Simpan" value="Simpan">
</form>