<a href="<?php echo base_url('buku/tambah');?>">Tambah buku Baru</a>

<TABLE>
    <th>buku</th>
    <th>penerbit</th>
    <th>pengarang</th>
    <th>UBAH</th>
    <th>HAPUS</th>
    <?php foreach ($buku as $a): ?>
    <tr>
        <td><?php echo $a['buku'] ?></td>
        <td><?php echo $a['penerbit'] ?></td>
        <td><?php echo $a['pengarang'] ?></td>
        <td><a href="<?php echo site_url('buku/get_edit/'.$a['id']);?>">UBAH</a></td>
        <td><a href="<?php echo site_url('buku/hapus/'.$a['id']);?>">HAPUS</a></td>
    </tr>
    <?php endforeach; ?>
</TABLE>