<form action="<?php echo base_url('buku/insert');?>" method="post">
    <label>buku</label>
    <input type="text" name="buku">
    <br>
    <label>penerbit</label>
    <input type="text" name="penerbit"> <br>
    <label>pengarang</label>
    <input type="text" name="pengarang">
    <br>
    <input type="submit" name="Simpan" value="Simpan">
</form>