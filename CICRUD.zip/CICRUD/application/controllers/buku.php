<?php
class buku extends CI_Controller{

    public function __construct()
    {
        parent :: __construct();
        $this->load->model('M_buku');
    }
    public function index(){
      $this->select();
       
    }
    public function select(){
       
        
        
        $data['judul']="Data buku Perpustakaan";
        $data['buku'] = $this->M_buku->Tampil();
        $this->load->view('template/header',$data);
        $this->load->view('buku/view_data',$data);
        $this->load->view('template/footer'); 
        
    }
    public function tambah (){
        $data['judul']="Tambah Data buku Perpustakaan";
        $this->load->view('template/header',$data);
        $this->load->view('buku/form_tambah');
        $this->load->view('template/footer');  
    }

    public function insert (){
        $buku=$this->input->post('buku');
        $penerbit=$this->input->post('penerbit');
        $pengarang=$this->input->post('pengarang');
        // echo $buku.$penerbit;
        $this->M_buku->save($buku,$penerbit,$pengarang);
        redirect('buku');
    }
    public function get_edit(){
        $id=$this->uri->segment(3);
        // echo "$id";
        $hasil= $this->M_buku->pilih_buku($id);
        $i=$hasil->row_array();
        $data = array(
            'buku' => $i['buku'],
            'penerbit' => $i['penerbit'],
            'pengarang' => $i['pengarang'],
            'id' => $i['id']
    );
    $data['judul']="Ubah Data buku Perpustakaan";
        $this->load->view('template/header',$data);
        $this->load->view('buku/form_ubah', $data);
        $this->load->view('template/footer');  
    }
    public function update(){
        $id=$this->input->post('id');
        $buku=$this->input->post('buku');
        $penerbit=$this->input->post('penerbit');
        $pengarang=$this->input->post('pengarang');
        
        //  echo"$id.$penerbit.$buku";
        $this->M_buku->edit($id,$buku,$penerbit,$pengarang);
        redirect('buku');

    }

    public function hapus(){
        $id=$this->uri->segment(3);
        // echo "hapus".$id;
        $this->M_buku->delete($id);
        redirect('buku');
    }
}

?>